/**
 * @param {number} a
 * @param {number} b
 * @return {number}
 */
var maximum = function (a, b) {
  return (Math.abs(a - b) + a + b) / 2;
};
