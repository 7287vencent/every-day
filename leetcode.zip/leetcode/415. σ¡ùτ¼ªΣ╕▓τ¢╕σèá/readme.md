### 题目 415. 字符串相加
#### 题目描述
给定两个字符串形式的非负整数 `num1` `和num2` ，计算它们的和。

提示：

1. ``num1`` 和 `num2` 的长度都小于 `5100`
2. `num1` 和 `num2` 都只包含数字 `0-9`
3. `num1` 和 `num2` 都不包含任何前导零
4. 你不能使用任何內建 `BigInteger` 库， 也不能直接将输入的字符串转换为整数形式
### 解题思路
[官方题解](https://leetcode-cn.com/problems/add-strings/solution/zi-fu-chuan-xiang-jia-by-leetcode-solution/)
#### 方法一：暴力法-模拟
- 直接按位相加就行了